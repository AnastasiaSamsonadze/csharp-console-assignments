﻿namespace B2;
class Program
{
    public static void Main()
    {
        int N = Convert.ToInt32(Console.ReadLine());
        int[] Amount = new int[N];
        string[] Brands = new string[N];
        for (int i = 0; i < N * 2; i++)
        {
            if (i % 2 == 0)
            {
                Brands[i / 2] = Console.ReadLine();
            }
            else
            {
                Amount[i / 2] = Convert.ToInt32(Console.ReadLine());
            }


        }
        int sum = Amount[0];
        for (int i = 1; i < N; i++)
        {
            if (Brands[0] == Brands[i])
            {
                sum = sum + Amount[i];


            }
        }
        Console.WriteLine(sum);
        Console.ReadLine();


    }
}


