﻿using System.Runtime.Intrinsics.X86;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numOfGifts = 0;
            do
            {
                Console.WriteLine("enter the count of the gifts: ");
                numOfGifts=Convert.ToInt32(Console.ReadLine()); 
            }while(!(numOfGifts>=1&&numOfGifts<=50));
            
            string[] giftName=new string[numOfGifts];
            int[]giftPrice=new int[numOfGifts];
            int[] giftQuantity=new int[numOfGifts];
            Console.WriteLine("enter the name, price and the quantity of the gifts: ");
            for (int i=0; i<numOfGifts;)
            {
                
                string input=Console.ReadLine();
                giftName[i] = input.Split(";")[0];
                giftPrice[i] = Convert.ToInt32(input.Split(";")[1]);
                giftQuantity[i] = Convert.ToInt32(input.Split(";")[2]);
                if (giftName[i].Length >= 1 && giftName[i].Length <= 50 && giftPrice[i]>=1&& giftPrice[i] <= 1000 && giftQuantity[i]>=0 && giftQuantity[i]<=100)
                {
                    i++;
                }
            }
            //taskA
            int tmpGiftPrice;
            string tmpGiftName;
            int tmpGiftQuantity;
            for (int i=0;i<numOfGifts;i++)
            {
                for(int j = i + 1; j < numOfGifts; j++)
                {
                    if (giftPrice[i] > giftPrice[j])
                    {
                        tmpGiftPrice = giftPrice[i];
                        giftPrice[i] = giftPrice[j];
                        giftPrice[j] = tmpGiftPrice;
                        tmpGiftQuantity = giftQuantity[i];
                        giftQuantity[i] = giftQuantity[j];
                        giftQuantity[j] = tmpGiftQuantity;
                        tmpGiftName = giftName[i];
                        giftName[i] = giftName[j];
                        giftName[j] = tmpGiftName;

                    }
                }
            }
            Console.WriteLine("Bottom 3 Christmas Gifts: ");
            for(int i = 0; i < 3; i++)
            {
                Console.WriteLine(" - " + giftName[i]);
            }
            //taskB
            int cnt=0;
            for(int i=0; i<numOfGifts; i++)
            {
                if (giftQuantity[i] == 0)
                {
                    cnt = cnt + 1;
                }
            }
            Console.WriteLine("Gifts with Zero Quantity:");
            Console.WriteLine(cnt);
        }
    }
}


