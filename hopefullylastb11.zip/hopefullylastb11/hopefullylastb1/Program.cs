﻿using System;

public class Program
{
    public static void Main()
    {
        int N = Convert.ToInt32(Console.ReadLine());
        int[] age = new int[N];
        int[] salary = new int[N];

        for (int i = 0; i < N; i++)
        {
            string input = Console.ReadLine();
            age[i] = Convert.ToInt32(input.Split(' ')[0]);
            salary[i] = Convert.ToInt32(input.Split(' ')[1]);
        }


        int ind = 0;
        int oldest = 0;
        for (int i = 0; i < N; i++)
        {
            if (age[i] > oldest)
            {
                oldest = age[i];
                ind = i;
            }
        }

        Console.WriteLine(salary[ind]);
        Console.ReadLine();
    }
}
